package PROJECT;

//Alper Yüce, Software Engineering Group B, 2. Semester





public class item {

	
	public static double Weight(int a,int b,int c,int d) {
		
		double w1 = d*0.2;
		double w2 = c*6.5;
		double w3 = a*2.6;		//Calculates the total weight of products
		double w4 = b*20; 
	    double w = w1+w2+w3+w4;
		return w;
	}

	
	public static double Volume(int a,int b,int c,int d) {
		
		 double v1 = b*0.3*0.3*0.2;            
	     double	v2 = a*0.6*0.5*0.5;		//Calculates the total volume of products
	     double v3 = d*1.2*0.4*0.8;
	     double v4 = c*1*1.5*0.5;
	     double v = v1+v2+v3+v4;
	     return v;
	}

}