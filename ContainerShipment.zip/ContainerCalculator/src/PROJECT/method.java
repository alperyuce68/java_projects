package PROJECT;






//Alper Yüce, Software Engineering Group B, 2. Semester




	

	import java.util.ArrayList;
	import java.util.List;				//Uses necessary packages 
	import PROJECT.item;
	import PROJECT.container;	
		
	public class method {

		
			public static void calculation(int a,int b,int c,int d,List list) {  //Sorts list of volume of each item in original list
				double SCV = container.SmallContainer_Volume(a,b,c); 	//Calls out the function from container package to calculate the total volume of small container
				double BCV = container.BigContainer_Volume(a,b,c);		//Calls out the function from container package to calculate the total volume of big container
				int index=0;
				int index1=0;
				int big=0;       		// Settles necessary variables 
				int small=0;
				int small1=0;
				double sum=0;
				double V=item.Volume(a, b, c, d);     // Calls out the function from item package to calculate the total volume of products
				double W=0;
				while (V>(2.5*SCV)) {                               //Checks for the volume is greater than 2.5 for small container 
					List<Double> l1=new ArrayList<Double>();          //Creates a list to add items 
					for (int i=0;i<list.size();i++) {                  
						if (sum<=BCV) {                        //Checks the big container is filled or not
							sum=sum+(Double)list.get(i);       //If it's not, adds items and updates the volume filled in big container
							l1.add((Double)list.get(i));       
							index=i;    //Stores till where the total items are filled in form of index number
						}else {                                         
							break;    //Breaks from loop, if it's filled
						}
					}
					big++;        //Updates the number of big containers filled 
					V=V-sum;      //Updates remaining volume that needs to be filled 
					sum=0;        //Resets sum equal to 0 to fill small container
				}
				if ((V>SCV)&&(V<BCV)) {
					List<Double> l1=new ArrayList<Double>();          //Creates list to add items 
					for (int i=0;i<list.size();i++) {                  
						if (sum<=BCV) {                       //Checks the big container is filled or not
							sum=sum+(Double)list.get(i);        //If it's not, adds items and updates the volume filled in big container
							l1.add((Double)list.get(i));        
							index=i;       //Stores till where the total items are filled in form of index number
						}else {                                         
							break;     //Breaks from loop, if it's filled
						}
					}
					big++;        //Updates the number of big containers filled 
					V=V-sum;       //Updates the remaining volume that needs to be filled 
					sum=0;        
					
				}
				                                           
				 while (V>0){
					List<Double> l1=new ArrayList<Double>();      //Creates a new list to add item in small container 
					if (index==0) {                              
						index=-1;                                 //Declares index=-1 if there is no big container filled 
					}
					for (int j=index+1;j<list.size();j++) {      //Moves from the next index number in the original list
						if (sum<=SCV) {
							sum=sum+(Double)list.get(j);
							l1.add((Double)list.get(j));           //Adds the items
							index1=j;
							if ((Double)list.get(j)==0.6*0.5*0.5) {
								W=W+6.5;                                    //Calculates the weight of items already added in the small container
							}else if((Double)list.get(j)==0.3*0.3*0.2) {            
								W=W+0.2;
							}else if((Double)list.get(j)==1*1.5*0.5) {
								W=W+20;
							}else {
								W=W+2.6;
								
							}
					}
			
					}
					if (W>500) {        //Checks total weight of small container
					    small=small+1;        // If it's more than 500 kgs , uses small container
					}else {							// or
						small1=small1+1;      // If it's less than 500 kgs , uses small container again
					}								// but for less than 500 kgs	
					V=V-sum;                                                 
				}
				 
				System.out.println("The number of big containers:"+big); 	//Prints number of big containers
			    System.out.println("The number of small containers for heavier shipment than 500 kgs:"+small);      //Prints number of small containers        
			    System.out.println("The number of small containers for less shipment than 500 kgs:"+small1);   	 //Prints number of small containers for less than 500 kgs
			    System.out.println("Total Cost:"+(big*1800+small*1200+small1*1000)+" Euros");		//Prints the total cost
			    
			
		}

		}







