package PROJECT;






//Alper Yüce, Software Engineering Group B, 2. Semester





import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import PROJECT.item;					//Uses necessary packages 
import PROJECT.method;
public class test {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the number of LCD Screens:");
		int d=input.nextInt();
		
		Scanner input1 = new Scanner(System.in);						
		System.out.println("Please enter the number of Desktops:");
		int c=input1.nextInt();
																	// Enter number of each items from user 
		Scanner input2 = new Scanner(System.in);							//and sets the inputs
		System.out.println("Please enter number of Laptops:");    
		int a=input2.nextInt();                                    
		
		Scanner input3 = new Scanner(System.in);
		System.out.println("Please enter the number of Mice:");                
		int b=input3.nextInt();
		
											 
		List l1=new ArrayList();			//Creates an array list of volume of each item 
		
		for (int i=0;i<d;i++) {
			l1.add(1.2*1.4*0.8);
		}
		for (int i=0;i<c;i++) {         
			l1.add(1*1.5*0.5);
		}
			for (int i=0;i<a;i++) {                                          
			l1.add(0.6*0.5*0.5);                                      
		}
		for (int i=0;i<b;i++) {
			l1.add(0.3*0.3*0.2);
		}
	
		l1.sort(null);                       //Sorts list in increasing order
		double V=item.Volume(a,b,c,d);        //Calls out the functions from item package for the total volume 
		double W=item.Weight(a, b, c, d);     //and weight                 
		
		System.out.println("Total Volume:"+V+" Cubic Meters");         //Prints the total volume                             
		System.out.println("Total Weight:"+W+" Kgs");			//Prints the total weight
		method.calculation(a, b, c, d,l1);        //Calls out the function for number of containers from method package and the total cost
                                                                              
		input.close();	                      //Close scanner
		
}
}


