package PROJECT;

//Alper Yüce, Software Engineering Group B, 2. Semester




public class container {
	
	public  static double BigContainer_Volume(int a, int b, int c) {
		double length = 2.59;
		double wide = 2.43;
		double height = 12.01;				//Calculates the volume of big container		
		double bcv = length*wide*height;
		return bcv;
		
	}
	
	public static double SmallContainer_Volume(int a, int b, int c) {
		double length = 2.59;
		double wide = 2.43;			//Calculates the volume of small container
		double height = 6.06;
		double scv = length*wide*height;			
		return scv;
	}

}