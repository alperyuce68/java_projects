package projects;

public class squareOfNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 0;
		int b;
		
		for(a = 0; a < 1000; a++) {
			b = a*a;
			
			System.out.println("Square of Number = "+b);
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
