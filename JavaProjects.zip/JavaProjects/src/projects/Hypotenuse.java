package projects;
import java.util.Scanner;
public class Hypotenuse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner triangle = new Scanner(System.in);
		
		System.out.println("Enter side a of the triangle: ");
		double a = triangle.nextDouble();
		
		System.out.println("Enter side b of the triangle: ");
		double b = triangle.nextDouble();
			
		int CC = (int)((a*a)+(b*b));
		
		System.out.println("triangle's hypotenuse: "+ CC);
	}

}
