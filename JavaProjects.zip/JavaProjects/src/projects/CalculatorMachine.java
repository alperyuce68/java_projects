package projects;

import java.util.Scanner;


public class CalculatorMachine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		String processes = "1-process add up\n"+"2-process subtract\n"+
		"3-process divide\n"+"4-process multiply";
		
		System.out.println(processes); 
		System.out.println("ENTER THE PROCESS WHICH YOU REQUIRED TO MAKE PROCESS");
		
		String maths_process = scan.nextLine();
	
		switch(maths_process) {
		case "1":
			System.out.println("Enter the number");
			int a = scan.nextInt();
			System.out.println("first number: "+ a);
			System.out.println("Enter the number");
			int b = scan.nextInt();
			System.out.println("second number: "+ b);
			System.out.println("total of add-up process: "+ (double)(a+b));	
		break;
		case "2":
			System.out.println("Enter the number");
			int c = scan.nextInt();
			System.out.println("first number: "+ c);
			System.out.println("Enter the number");
			int d = scan.nextInt();
			System.out.println("second number: "+ d);
			System.out.println("conclusion of subtract process: "+ (double)(c-d));	
		break;
		case "3":
			System.out.println("Enter the number");
			int e = scan.nextInt();
			System.out.println("first number: "+ e);
			System.out.println("Enter the number");
			int f = scan.nextInt();
			System.out.println("second number: "+ f);
			System.out.println("conclusion of division process: "+ (double)(e/f));	
		break;
		case "4":
			System.out.println("Enter the number");
			int g = scan.nextInt();
			System.out.println("first number: "+ g);
			System.out.println("Enter the number");
			int h = scan.nextInt();
			System.out.println("second number: "+ h);
			System.out.println("conclusion of multiply process: "+ (double)(g*h));	
		break;
		default:
			System.out.println("Invalid process has been chosen. Please, try again...");
				
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
