package projects;

public class fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		int i = 0;
		int f = 0;
		int t;
		for(i = 0; i <10000000; i++) {	 
				System.out.println("fibonacci = " + i);
				 t = i + f;
				 i = f;
				 f = t;	
			}
		}


	}


