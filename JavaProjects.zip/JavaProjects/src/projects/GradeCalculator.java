package projects;

import java.util.Scanner;

public class GradeCalculator {
    /*
    Calculate a letter grade by taking Midterm1, Midterm2, and Final scores from the user.
    Also, take the user's overall GPA from the school and display an advice message based on the 
    condition of getting a DD and having a GPA below 2.50.

    Midterm1 will affect 30% of the total grade.

    Midterm2 will affect 30% of the total grade.

    The final will affect 40% of the total grade.


    Total Grade >=  90 -----> AA

    Total Grade >=  85 -----> BA

    Total Grade >=  80 -----> BB

    Total Grade >=  75 -----> CB

    Total Grade >=  70 -----> CC

    Total Grade >=  65 -----> DC

    Total Grade >=  60 -----> DD

    Total Grade >=  55 -----> FD

    Total Grade <  55 -----> FF

    */
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Midterm1 : ");
        int midterm1  = scanner.nextInt();
        System.out.print("Midterm2 : ");
        int midterm2  = scanner.nextInt();
        System.out.print("Final : ");
        int finalScore  = scanner.nextInt();
        System.out.print("Your GPA:");
        double gpa = scanner.nextDouble();
        
        double totalGrade = (midterm1 * 3 / 10.0) + (midterm2 * 3 / 10.0) + (finalScore * 4 / 10.0);
        
        if (totalGrade >= 90) {
            
            System.out.println("You got an AA...");
        }
        else if (totalGrade >= 85) {
            System.out.println("You got a BA...");
        }
        else if (totalGrade >= 80) {
            System.out.println("You got a BB...");
        }
        else if (totalGrade >= 75) {
            System.out.println("You got a CB...");
        }
        else if (totalGrade >= 70) {
            System.out.println("You got a CC...");
        }
        else if (totalGrade >= 65) {
            System.out.println("You got a DC...");
        }
        else if (totalGrade >= 60) {
            System.out.println("You got a DD...");
            
            if (gpa < 2.50) {
                
                System.out.println("You got a DD and your GPA is low. You may want to consider retaking this course.");
            }
        }
        else if (totalGrade >= 55) {
            System.out.println("You got an FD and failed...");
        }
        else {
            System.out.println("You got an FF and failed...");
        }
        
    }
}
