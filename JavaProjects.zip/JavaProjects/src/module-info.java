
module Cards {
	requires java.desktop;
}